// JavaScript functionality can be added here
console.log('Welcome to Online Shopping');