# 🛒 Online Shopping Website

Welcome to **Online Shopping**, a responsive and modern e-commerce website project made using **HTML, CSS, JavaScript** and hosted on **GitHub Pages**.

## 📌 Features

- 👨‍💻 Multi-page layout (Home, About, Contact, Gallery, Products)
- 🔄 Image slider on homepage
- 📱 Mobile responsive design
- 🖼️ Photo gallery
- 🎨 Modern animations
- 🖋️ Hindi/English (Bilingual content)
- 🌐 Fully hosted on GitHub Pages

## 📁 Pages Included

- `index.html` – Home page
- `about.html` – About us
- `contact.html` – Contact form
- `gallery.html` – Image gallery
- `products.html` – Product listings

## 📷 Preview

![Website Screenshot](screenshot.png)

## 🚀 How to View

1. Go to: [https://your-username.github.io/online-shopping](https://your-username.github.io/online-shopping)
2. Explore the site live on GitHub Pages!

## 🧑‍💻 Author

**Abhishek Pathak**  
Made with ❤️ for a school/college project.

## 📄 License

This project is licensed under the **MIT License** – feel free to use and modify it.
